"use strict";
(() => {
  const filters = document.querySelector("[data-filters]");
  if (filters) {
    filters.hidden = false;
    const search = document.querySelector("#busca");
    const category = document.querySelector("#categoria");
    const normalize = value => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const update = () => {
      let count = 0;
      for (const item of document.querySelectorAll("[data-search-item]")) {
        const visible = normalize(item.textContent).includes(normalize(search.value.trim())) && (category.value === "Todas" || item.dataset.category === category.value);
        item.hidden = !visible;
        if (visible) count++;
      }
      document.querySelector("#empty").hidden = count > 0;
      document.querySelector("#resultados").textContent = `${count} resultado(s)`;
    };
    search.addEventListener("input", update);
    category.addEventListener("change", update);
    update();
  }
  const cart = new Map();
  const cartPanel = document.querySelector("[data-cart]");
  if (cartPanel) {
    cartPanel.hidden = false;
    const format = value => new Intl.NumberFormat("pt-BR", {style: "currency", currency: "BRL"}).format(value / 100);
    const render = () => {
      const list = document.querySelector("#cart-list");
      list.replaceChildren();
      let total = 0;
      for (const [id, item] of cart) {
        total += item.price * item.quantity;
        const li = document.createElement("li");
        li.append(document.createTextNode(`${item.title} × ${item.quantity} — ${format(item.price * item.quantity)}`));
        const remove = document.createElement("button");
        remove.type = "button";
        remove.textContent = "Remover";
        remove.setAttribute("aria-label", `Remover ${item.title}`);
        remove.addEventListener("click", () => { cart.delete(id); render(); });
        li.append(remove);
        list.append(li);
      }
      if (!cart.size) { const li = document.createElement("li"); li.textContent = "Seu carrinho está vazio."; list.append(li); }
      document.querySelector("#cart-total").textContent = `Total: ${format(total)}`;
    };
    document.querySelectorAll("[data-add]").forEach(button => {
      button.hidden = false;
      button.addEventListener("click", () => {
        const id = button.dataset.add;
        const item = cart.get(id) || {title: button.dataset.title, price: Number(button.dataset.price), quantity: 0};
        item.quantity++;
        cart.set(id, item);
        render();
      });
    });
    render();
  }
  const tasks = document.querySelector("[data-tasks]");
  if (tasks) {
    tasks.hidden = false;
    const form = document.querySelector("#tarefas");
    form.addEventListener("submit", event => {
      event.preventDefault();
      const input = form.elements.namedItem("task");
      const text = input.value.trim();
      if (!text) { input.setCustomValidity("Digite uma tarefa."); input.reportValidity(); return; }
      const li = document.createElement("li");
      const label = document.createElement("label");
      const check = document.createElement("input");
      check.type = "checkbox";
      label.append(check, document.createTextNode(text));
      check.addEventListener("change", () => { label.style.textDecoration = check.checked ? "line-through" : "none"; });
      li.append(label);
      document.querySelector("#task-list").append(li);
      form.reset();
      input.focus();
    });
    form.elements.namedItem("task").addEventListener("input", event => event.target.setCustomValidity(""));
  }
  const contact = document.querySelector("#contato-form");
  if (contact) {
    contact.hidden = false;
    contact.addEventListener("submit", event => {
      event.preventDefault();
      document.querySelector("#form-status").textContent = "Demonstração concluída: nenhum dado foi enviado ou salvo.";
    });
  }
})();
