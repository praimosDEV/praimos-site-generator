# Presets e proveniência

Referências corretas inspecionadas em 24/10/2026: pastas `blog/` e `loja/` fornecidas pelo usuário. A referência React/Vite com roxo e serifas examinada inicialmente pertencia a outro diretório e foi descartada. Nenhum arquivo de ambiente, contato, identificador de anúncio ou imagem original é distribuído neste pacote.

| Preset | Origem confirmada | Elementos observados |
| --- | --- | --- |
| blog | `blog/styles.css`, `blog/index.html`, `blog/develop.md`, `blog/script.js` | Fundo #0b0f1e, superfícies #151b2e/#1b2338, texto #f1f5f9, índigo #6366f1/#818cf8, raios 16/10px, container 1180px, Inter/Orbitron; hero amplo, partículas, cartões por categoria, PT/EN/ES, artigos estáticos |
| loja | `loja/src/styles.css`, `loja/src/routes/index.tsx`, `loja/src/components/site/ProductCard.tsx` | Fundo oklch(0.17 0.026 258), superfície oklch(0.22 0.028 258), ciano oklch(0.74 0.13 218), preço verde, Inter/Oxanium; catálogo por categoria, capas 16:9, filtros na URL, preços e detalhe por slug |

O starter usa fontes do sistema e arte abstrata criada em CSS para funcionar offline e evitar redistribuir ativos sem licença confirmada. Aproxima cores da loja em HEX; a fonte original não é embutida. Identidade, imagens e texto podem ser substituídos pelo briefing.

Reutilize hierarquia, container, escala de espaços, cartões e estados. Cores e intensidade dos efeitos são escolhas por projeto. Glow/parallax não devem interferir na leitura ou em painéis de dados. Conteúdo permanece visível antes do JS; respeite redução de movimento, foco e toque. Não use overflow hidden para encobrir erros de responsividade.

## Particularidades dos originais

O blog mantém artigos dentro de `blog/<slug>/index.html`, JSON e fallback `posts-data.js` sincronizados e sitemap atualizado. Agendamento oculto apenas no cliente não mantém um artigo estático confidencial: uma URL pode ser acessada diretamente; conteúdo embargado precisa ser publicado pelo processo de build/servidor no horário autorizado.

A loja efetivamente usa TanStack Start/Router, React, Tailwind e Supabase conforme package.json, apesar de o README mencionar Next.js. Arquivos de mock e download demonstrativo existem; login, RLS, pagamentos e acesso a compras precisam de verificação própria. O AGENTS.md da loja proíbe reescrever histórico publicado conectado ao Lovable; preserve essa regra ao trabalhar no original.
