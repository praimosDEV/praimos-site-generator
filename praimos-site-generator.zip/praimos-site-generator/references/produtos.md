# Contratos por produto

| Tipo | Fluxo da base incluída | Evolução conforme briefing |
| --- | --- | --- |
| blog | Busca local, cartões e artigos em HTML com URL própria | Categorias, autores, datas, conteúdo multilíngue consistente e agendamento pelo build/servidor |
| loja | Busca, categorias, detalhe com URL própria e carrinho em memória | Catálogo persistido, favoritos, biblioteca, acesso a download, checkout e pedidos validados no servidor |
| plataforma | Lista de tarefas, adicionar e concluir em memória | Entidade de negócio, CRUD persistido, autenticação, permissões por usuário/organização |
| vendas | Oferta de exemplo, benefícios, FAQ e contato demonstrativo | Oferta real, condições, CTA ao provedor e provas sociais verificadas |
| software | Recursos e demonstração de contato | Versões, requisitos, documentação, download assinado e destino real |
| institucional | Serviços, apresentação e contato demonstrativo | Dados da organização, portfólio autorizado e canal real |
| landing | Proposta única, recursos e contato demonstrativo | Integração de lead/agenda e confirmação real |

Não crie depoimentos, logos de clientes, descontos, urgência ou métricas fictícias apresentados como verdadeiros. Exemplos são rotulados. O starter não gera autenticação, pagamentos, envio de e-mail, tradução automática ou backend. Combinações compartilham tokens e navegação sem carregar recursos desnecessários.

Mantenha pt-BR no HTML, texto e formatos; use Intl para BRL. Outros idiomas exigem paridade das páginas e links, não só um seletor visual. Peça domínio e conteúdo reais apenas quando necessários à publicação. Não copie domínios ou scripts de anúncios das referências.
