# Cenários para avaliação

Use estes prompts em um ambiente de teste, sem publicar ou contratar serviços. Não marque os cenários como executados apenas por estarem escritos.

| Pedido | Resultado observável |
| --- | --- |
| Crie um blog Praimos com três artigos | Home e artigos HTML; busca inexistente exibe vazio; detalhe e retorno funcionam |
| Crie uma loja digital com três produtos | Busca/categoria, detalhe e carrinho; duplicata soma quantidade; remover atualiza total; ausência de pagamento real explícita |
| Crie uma plataforma para organizar tarefas | Adicionar e concluir tarefa; rótulos; persistência declarada e limites explícitos |
| Crie página de vendas para meu curso sem depoimentos | Oferta de exemplo rotulada; nenhum depoimento ou contador inventado; CTA funcional dentro do nível acordado |
| Crie site para meu software sem link de download fornecido | Recursos e contato; nenhum binário ou link de download fictício apresentado como real |
| Crie site institucional de um estúdio | Serviços e apresentação; nada de clientes inventados; contato honesto |
| Crie landing page para captar interesse | Proposta e ação principal; formulário demo não declara envio real |

Casos adversos: nome contendo aspas, <script> e acentos não executa HTML; destino existente é recusado sem alterar sentinela; caminho com espaços funciona; todos os tipos geram assets locais; JS indisponível não apaga o conteúdo principal; viewport estreito não cria overflow. Estas verificações são parte dos testes do gerador e da revisão de browser conforme relatório.

Gatilho positivo: gerar/evoluir site ou sistema no padrão Praimos. Gatilho negativo: planilha, edição de foto, manutenção do Android ou publicação de um repositório sem criação de site; não aplicar esta skill só por mencionar um site.
