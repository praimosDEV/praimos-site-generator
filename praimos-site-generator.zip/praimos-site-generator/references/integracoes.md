# Integrações e níveis de entrega

## Demo local

Os sites gerados são estáticos e marcados como demonstração. Catálogo e artigos são fictícios. Carrinho e tarefas ficam em memória e se perdem no reload. Formulário usa apenas um assunto de exemplo e declara que nada é enviado; não solicite dados pessoais reais. A matriz FEATURES.md deve distinguir implementado, ausente e não verificado.

## Sandbox

Separe apresentação, regras e adaptadores de dados. Preserve gerenciador e lockfile existentes. Confira documentação oficial da versão ao integrar APIs. Arquivos de exemplo de ambiente contêm apenas nomes de variáveis e valores fictícios. Não distribua URLs privadas, tokens ou chaves de serviço.

Supabase: cliente apenas com chave publicável, políticas por linha para dados privados, autorização no servidor, migrações versionadas e teste de acesso negado. Não conceda admin por estado no navegador. Diferencie carregamento, erro, vazio e registro inexistente; fallback demo deve ser explícito, nunca encobrir falha de produção.

Loja digital: preço e total calculados no servidor em centavos inteiros; pagamento confirmado por webhook com assinatura validada e processamento idempotente. Redirecionar para uma página de sucesso não comprova pagamento. A biblioteca e downloads devem exigir aquisição válida, URLs assinadas de curta duração quando aplicáveis e autorização por arquivo. Compra e re-download não podem ser concedidos por uma alteração livre feita no cliente.

## Produção

Requer configuração do ambiente, serviços e destino autorizados, testes pertinentes, observação de falhas e procedimento de recuperação. Nunca anuncie produção com base num protótipo. Pix, cartão ou outros métodos dependem do provedor escolhido, não são incluídos automaticamente. Não adicione campos CPF/CNPJ ou pixels de marketing sem necessidade. Requisitos de privacidade, retenção, políticas e termos precisam ser definidos pelo responsável e verificados em fontes oficiais quando aplicáveis; a skill não certifica conformidade jurídica.
