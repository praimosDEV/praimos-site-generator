# Verificar e encerrar

Registre cada critério aplicável, evidência, resultado e limitação em REVISAO.md do projeto entregue.

- Rode build, tipos e verificações existentes quando aplicáveis. No starter estático, rode os testes do gerador, `node --check assets/app.js` e confira os arquivos servidos.
- Navegue no fluxo principal em desktop e celular, por exemplo 1440/390px. Verifique ausência de overflow horizontal, menus, busca, detalhe, links de retorno e URL profunda aberta diretamente. Capture evidências.
- Confira teclado, foco visível, rótulos, títulos, ordem de navegação, contraste e redução de movimento. Não anuncie auditoria completa de acessibilidade sem executá-la.
- Dados assíncronos precisam de estados de carregamento, erro, vazio e sucesso testados. No starter com HTML pré-gerado, estados de rede são não aplicáveis. Busca sem resultado deve ser visível.
- Verifique carrinho duplicado, remoção e total; formulário não pode confirmar envio inexistente. Tarefas e carrinho precisam explicar a perda no reload. Conteúdo principal deve permanecer legível sem JavaScript; controles que dependem dele podem ser ocultados até a inicialização.
- SEO: título e descrição específicos por página; artigos/detalhes em HTML. Domínio confirmado permite canonical, OG absoluto e sitemap; sem domínio, declare a pendência e não invente endereço público. Metadados de rating só com dados reais.
- Imagens com dimensões, lazy loading fora da primeira dobra e ativos com uso permitido. Meça antes de prometer desempenho.
- Publicação: seleção explícita de arquivos, sem .env, chaves, dados pessoais, node_modules ou cópias integrais dos originais. Preserve os sites originais e histórico publicado.

Termine com critérios atendidos e nenhuma falha bloqueante conhecida. Registre critérios não executados, referência ausente ou serviço externo pendente. Uma revisão de texto pelo Claude não substitui testes de código e navegador.
