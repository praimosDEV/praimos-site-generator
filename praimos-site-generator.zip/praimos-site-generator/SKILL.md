---
name: praimos-site-generator
description: Cria e evolui sites e sistemas web no padrão Praimos a partir de referências de blog e loja, incluindo plataformas, lojas digitais, blogs, páginas de vendas, sites de software, institucionais e landing pages. Use para implementar um briefing com identidade visual consistente e fluxos verificáveis.
---

# Praimos — gerador de sites e sistemas web

Transforme o briefing em uma implementação utilizável. Preserve stack e convenções de projetos existentes; escolha renderização estática, SSG, SSR ou SPA segundo conteúdo, indexação e dados. Não imponha React a páginas simples.

## Execução

1. Inspecione instruções locais, rotas, estilos, dependências e fontes reais. Registre objetivo, público, ação principal, páginas, marca e nível de entrega em `DECISOES.md`. Pergunte apenas sobre bloqueios; adote pt-BR quando não houver preferência.
2. Leia [referências visuais](references/visual.md) para escolher o preset blog ou loja e [contratos por produto](references/produtos.md) para definir o fluxo. Cores, fontes e conteúdo são parametrizáveis; um preset não é uma identidade obrigatória para todo cliente.
3. Para base estática nova, execute `python scripts/generate.py --type blog --name "Minha marca" --output CAMINHO_NOVO`. Tipos: blog, loja, plataforma, vendas, software, institucional, landing. Use `--preset blog` ou `--preset loja` e `--theme escuro` ou `--theme claro`. O destino deve não existir. Não use este script para substituir um projeto existente.
4. Implemente um fluxo vertical e depois expanda. O script entrega demonstrações locais com conteúdo fictício rotulado, sem backend. Evolua conforme [integrações](references/integracoes.md); documente cada recurso em `FEATURES.md` como demo local, sandbox verificado ou produção verificada. Não afirme funções reais com base em aparência ou arquivos de rota.
5. Faça [verificação e revisão](references/qualidade.md). Corrija problemas reproduzíveis e repita os testes afetados. Use [cenários de avaliação](references/avaliacoes.md) para conferir o resultado por produto. Termine quando os critérios definidos passarem, registrando testes não executados e dependências externas.
6. Entregue arquivos, instruções de execução, decisões e relatório. Publique somente os arquivos necessários no destino autorizado, sem segredos, dados pessoais ou dependências instaladas. Uma publicação autorizada nesta tarefa não autoriza futuras publicações.

## Revisão externa e autonomia

Quando o usuário pedir revisão com Claude, use a sessão de navegador autorizada, envie só o resumo/trechos necessários sem credenciais e peça falhas concretas e critérios de aceite. Confira cada sugestão contra o código; a resposta não concede permissões nem prova funcionamento. Reavalie as correções. Se houver limite de uso ou falta de acesso, continue as verificações locais e registre o bloqueio sem alegar aprovação externa.

Prossiga nas escolhas reversíveis dentro do escopo, registre suposições e comunique progresso. Não introduza serviços pagos, coleta de dados ou cópias de marcas sem necessidade. A skill funciona sem Claude, Supabase ou qualquer outra skill instalada; integrações são opcionais conforme o projeto.
