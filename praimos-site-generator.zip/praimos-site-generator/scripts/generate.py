#!/usr/bin/env python3
"""Generate offline Praimos demos without overwriting an existing destination."""
import argparse
from html import escape
import json
from pathlib import Path
import shutil

TYPES = ('blog', 'loja', 'plataforma', 'vendas', 'software', 'institucional', 'landing')
COPY = {
 'blog': ('Ideias que merecem ir além.', 'Histórias, descobertas e bastidores para quem cria o próximo capítulo.', 'Explorar artigos'),
 'loja': ('Seu próximo universo começa aqui.', 'Explore jogos, softwares e ferramentas para transformar suas ideias.', 'Explorar catálogo'),
 'plataforma': ('Menos ruído. Mais progresso.', 'Um espaço para organizar seu trabalho e acompanhar o que importa.', 'Abrir painel'),
 'vendas': ('Dê o próximo passo na sua criação.', 'Uma oferta de exemplo para apresentar sua proposta com clareza.', 'Conhecer a oferta'),
 'software': ('Da ideia ao que você pode criar.', 'Ferramentas pensadas para simplificar o processo e ampliar possibilidades.', 'Explorar recursos'),
 'institucional': ('Criamos o que vem a seguir.', 'Um estúdio independente que conecta ideias, pessoas e experiências digitais.', 'Conhecer serviços'),
 'landing': ('Grandes ideias começam com uma conversa.', 'Conheça uma proposta simples para transformar intenção em movimento.', 'Conhecer a proposta'),
}
POSTS = [('criacao', 'Criação', 'Do primeiro esboço ao primeiro mundo', 'Um processo começa pequeno: uma ideia, uma escolha e espaço para experimentar.'), ('design', 'Design', 'Interfaces que convidam a explorar', 'Hierarquia, contraste e ritmo ajudam cada pessoa a encontrar seu próximo passo.'), ('tecnologia', 'Tecnologia', 'Ferramentas para tirar ideias do papel', 'Escolher uma ferramenta começa por entender o problema que ela precisa resolver.')]
PRODUCTS = [('orbita', 'Jogos', 'Órbita', 'Uma aventura de exploração entre paisagens e novas possibilidades.', 2990), ('studio', 'Softwares', 'Studio Kit', 'Uma coleção de ferramentas para seu próximo projeto criativo.', 4990), ('formas', 'Assets', 'Formas & Mundos', 'Elementos visuais de exemplo para construir novas experiências.', 1990)]

def money(cents):
    return f'R$ {cents // 100},{cents % 100:02d}'

def _build(kind, name, destination, preset=None, theme='escuro'):
    if kind not in TYPES or theme not in ('escuro', 'claro') or preset not in (None, 'blog', 'loja'):
        raise ValueError('Tipo, preset ou tema inválido')
    if not name.strip() or len(name) > 100:
        raise ValueError('Nome deve conter entre 1 e 100 caracteres')
    destination = Path(destination).expanduser().absolute()
    preset = preset or ('loja' if kind == 'loja' else 'blog')
    safe_name = escape(name, quote=True)
    assets = Path(__file__).resolve().parent.parent / 'assets'
    shutil.copytree(assets, destination / 'assets')
    title, subtitle, cta = COPY[kind]
    def page(title, description, body, depth=0):
        base = '../' * depth
        return f"""<!doctype html>
<html lang="pt-BR" data-preset="{preset}" data-theme="{theme}">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape(title)} | {safe_name}</title><meta name="description" content="{escape(description, quote=True)}">
<meta name="robots" content="noindex,nofollow"><meta property="og:title" content="{escape(title, quote=True)} | {safe_name}">
<meta property="og:description" content="{escape(description, quote=True)}"><link rel="stylesheet" href="{base}assets/styles.css">
<script src="{base}assets/app.js" defer></script></head>
<body><a class="skip" href="#conteudo">Pular para conteúdo</a>
<header><a class="brand" href="{base}index.html"><span class="brand-icon" aria-hidden="true">P</span>{safe_name}</a>
<nav aria-label="Principal"><a href="{base}index.html#explorar">Explorar</a><a href="{base}index.html#sobre">Sobre</a><a href="{base}index.html#contato">Contato</a></nav></header>
<div class="demo">Modo demonstração · conteúdo fictício · sem pagamento, login ou envio real</div>
<main id="conteudo">{body}</main>
<footer><a class="brand" href="{base}index.html">{safe_name}</a><p>Uma base Praimos para sua próxima ideia.</p><span>Demonstração local · personalize antes de publicar</span></footer>
</body></html>"""
    def write(relative, contents):
        path = destination / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents, encoding='utf-8', newline='\n')
    def art(index, text):
        return f'<div class="art art-{index}" role="img" aria-label="{escape(text, quote=True)}"><span aria-hidden="true">0{index + 1}</span></div>'
    cards = ''
    if kind == 'blog':
        for index, (slug, category, heading, text) in enumerate(POSTS):
            cards += f'<article class="card" data-search-item data-category="{category}">{art(index, "Ilustração abstrata de exemplo")}<div class="card-body"><p class="eyebrow">{category} · exemplo editorial</p><h3><a href="blog/{slug}/index.html">{heading}</a></h3><p>{text}</p><a class="text-link" href="blog/{slug}/index.html">Ler artigo →</a></div></article>'
            body = f'<article class="reading"><a class="text-link" href="../../index.html#explorar">← Voltar aos artigos</a><p class="eyebrow">{category} · conteúdo de exemplo</p><h1>{heading}</h1><p class="lead">{text}</p>{art(index, "Ilustração abstrata de exemplo")}<h2>Um espaço para experimentar</h2><p>Este artigo demonstra o formato de leitura. Substitua por conteúdo próprio e verificado antes de publicar.</p><p>Uma boa experiência oferece contexto, linguagem clara e um próximo passo que faz sentido para quem lê.</p></article>'
            write(f'blog/{slug}/index.html', page(heading, text, body, 2))
    elif kind == 'loja':
        for index, (slug, category, heading, text, cents) in enumerate(PRODUCTS):
            button = f'<button class="button" type="button" data-add="{slug}" data-title="{heading}" data-price="{cents}" hidden>Adicionar ao carrinho</button>'
            cards += f'<article class="card" data-search-item data-category="{category}">{art(index, "Capa abstrata de demonstração")}<div class="card-body"><p class="eyebrow">{category} · produto de exemplo</p><h3><a href="produto/{slug}/index.html">{heading}</a></h3><p>{text}</p><p class="price">{money(cents)}</p><a class="text-link" href="produto/{slug}/index.html">Ver produto →</a></div></article>'
            body = f'<article class="reading"><a class="text-link" href="../../index.html#explorar">← Voltar ao catálogo</a><p class="eyebrow">{category} · produto fictício</p><h1>{heading}</h1><p class="lead">{text}</p>{art(index, "Capa abstrata de demonstração")}<h2>Conheça o produto</h2><p>Produto demonstrativo. Nenhum arquivo está à venda ou disponível para download.</p><p class="price">{money(cents)}</p>{button}<noscript><p>Ative JavaScript para experimentar o carrinho local.</p></noscript></article>' + cart()
            write(f'produto/{slug}/index.html', page(heading, text, body, 2))
    else:
        descriptions = ['Uma estrutura clara para começar e evoluir.', 'Uma experiência que funciona em diferentes telas.', 'Espaço para conectar conteúdo e serviços reais.']
        for index, heading in enumerate(['Feito para explorar', 'Simples de usar', 'Pronto para evoluir']):
            cards += f'<article class="card">{art(index, "Composição abstrata")}<div class="card-body"><p class="eyebrow">Recurso de exemplo · 0{index+1}</p><h3>{heading}</h3><p>{descriptions[index]}</p></div></article>'
    search = ''
    if kind in ('blog', 'loja'):
        options = ['Todas'] + ([p[1] for p in PRODUCTS] if kind == 'loja' else [p[1] for p in POSTS])
        search = '<div class="filters" hidden data-filters><label>Buscar<input type="search" id="busca" placeholder="O que você procura?"></label><label>Categoria<select id="categoria">' + ''.join(f'<option>{opt}</option>' for opt in options) + '</select></label><p id="resultados" role="status" aria-live="polite"></p></div>'
    extra = cart() if kind == 'loja' else ''
    if kind == 'plataforma':
        extra = '<section class="section panel" id="painel" data-tasks hidden><p class="eyebrow">Painel local</p><h2>Seu próximo passo</h2><p>Tarefas ficam em memória e se perdem ao recarregar.</p><form id="tarefas"><label>Nova tarefa<input name="task" required maxlength="120" placeholder="Ex.: organizar o lançamento"></label><button class="button">Adicionar tarefa</button></form><ul id="task-list"></ul></section>'
    if kind == 'vendas':
        extra = '<section class="section panel"><p class="eyebrow">Oferta de exemplo</p><h2>Uma proposta com clareza.</h2><p>Defina preço, conteúdo e condições reais antes de publicar sua oferta.</p><details><summary>Como funciona?</summary><p>Esta é uma base demonstrativa. Não há cobrança nem matrícula.</p></details><a class="button" href="#contato">Conversar sobre a proposta</a></section>'
    cta_target = "painel" if kind == "plataforma" else "explorar"
    body = f'<section class="hero"><div><p class="eyebrow">Praimos / {kind} · base demonstrativa</p><h1>{title}</h1><p class="lead">{subtitle}</p><a class="button" href="#{cta_target}">{cta} ↗</a><p class="caption">Identidade própria. Experiências conectadas.</p></div><div class="hero-art" aria-hidden="true"><div class="orbit"></div><div class="sphere"></div><span>PRAIMOS<br>EXPLORE / CREATE</span></div></section><section class="section" id="explorar"><div class="section-head"><div><p class="eyebrow">Explore possibilidades</p><h2>{"Últimas histórias" if kind == "blog" else "Encontre seu próximo favorito" if kind == "loja" else "Feito para suas ideias"}</h2></div><span class="caption">Conteúdo de exemplo / 01—03</span></div>{search}<div class="grid">{cards}</div><p id="empty" hidden>Nenhum resultado encontrado. Tente outro termo ou categoria.</p></section>{extra}<section class="section about" id="sobre"><p class="eyebrow">Sobre esta experiência</p><h2>O começo de algo seu.</h2><p>Uma base inspirada no universo visual Praimos. Troque os exemplos pela história, pelos produtos e pelas ideias da sua marca.</p></section><section class="section panel" id="contato"><p class="eyebrow">Próximo passo</p><h2>Vamos dar forma à ideia?</h2><p>Formulário demonstrativo. Não digite dados pessoais: nada será enviado.</p><form id="contato-form" hidden><label>Assunto de exemplo<input name="subject" required maxlength="120" placeholder="Ex.: meu próximo projeto"></label><button class="button">Experimentar formulário</button><p id="form-status" role="status"></p></form><noscript><p>O formulário demonstrativo requer JavaScript. Nenhum envio real está configurado.</p></noscript></section>'
    write('index.html', page(title, subtitle, body))
    write('404.html', page('Página não encontrada', 'A página solicitada não existe.', '<section class="reading"><h1>Página não encontrada</h1><a class="button" href="index.html">Voltar ao início</a></section>'))
    write('robots.txt', 'User-agent: *\nDisallow: /\n')
    manifest = {'type': kind, 'name': name, 'preset': preset, 'theme': theme, 'level': 'demo-local', 'routes': ['index.html', '404.html'] + sorted(str(p.relative_to(destination)).replace('\\', '/') for p in destination.glob('**/index.html') if p.parent != destination)}
    write('site.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    write('FEATURES.md', '# Estado dos recursos\n\nNível: demo local.\n\n- HTML e navegação: implementados.\n- Busca/categoria: locais em blog e loja.\n- Carrinho: apenas memória na página de produto; não atravessa páginas nem recarga.\n- Tarefas: apenas memória na plataforma.\n- Contato: demonstrativo; nenhum dado enviado.\n- Login, pagamentos, banco, download e envio real: ausentes.\n- SEO público: pendente de domínio; demo com noindex e robots restritivo.\n- Testes de navegador: devem ser executados no projeto gerado.\n')
    write('DECISOES.md', f'# Decisões\n\nTipo: {kind}\nPreset: {preset}\nTema: {theme}\nRenderização: HTML estático, com JS progressivo.\nFontes: sistema. Arte: CSS local. Dados: exemplos fictícios.\nSem dependências ou chamadas remotas.\n')
    write('README.md', '# Executar\n\nNa pasta deste site: `python -m http.server 4173 --bind 127.0.0.1`. Abra http://127.0.0.1:4173.\n\nNão precisa instalar dependências. Conteúdo fictício, sem backend. Recursos em memória zeram ao recarregar e não atravessam páginas. Para publicar, substitua conteúdo, defina domínio/metadados e revise noindex/robots. Consulte FEATURES.md.\n')
    return destination

def generate(kind, name, destination, preset=None, theme='escuro'):
    if kind not in TYPES or theme not in ('escuro', 'claro') or preset not in (None, 'blog', 'loja'):
        raise ValueError('Tipo, preset ou tema inválido')
    if not name.strip() or len(name) > 100:
        raise ValueError('Nome deve conter entre 1 e 100 caracteres')
    target = Path(destination).expanduser().absolute()
    assets = Path(__file__).resolve().parent.parent / 'assets'
    if not (assets / 'styles.css').is_file() or not (assets / 'app.js').is_file():
        raise FileNotFoundError('Assets da skill ausentes')
    # Exclusive creation refuses existing files, directories and symlinks.
    # The caller supplies an existing parent; no ancestor folders are created.
    target.mkdir(exist_ok=False)
    expected = target.resolve()
    identity = target.stat().st_ino
    try:
        return _build(kind, name, target, preset, theme)
    except Exception:
        # Roll back only this call's newly owned directory, never a replacement.
        if target.exists() and not target.is_symlink() and target.resolve() == expected and target.stat().st_ino == identity:
            shutil.rmtree(target)
        raise

def cart():
    return '<section class="section panel" data-cart hidden><p class="eyebrow">Carrinho de demonstração</p><h2>Sua seleção</h2><p>Somente nesta página. Os itens se perdem ao sair ou recarregar. Sem checkout ou cobrança.</p><ul id="cart-list"></ul><p id="cart-total" class="price" role="status" aria-live="polite">Total: R$ 0,00</p></section>'

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--type', choices=TYPES, required=True)
    parser.add_argument('--name', default='Praimos')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--preset', choices=('blog', 'loja'))
    parser.add_argument('--theme', choices=('escuro', 'claro'), default='escuro')
    args = parser.parse_args()
    try:
        print(generate(args.type, args.name, args.output, args.preset, args.theme))
    except (ValueError, OSError) as exc:
        parser.exit(1, f'Não foi possível gerar: {exc}\n')
