"""Behavioral checks for the generated package; standard library only."""
import json
from html.parser import HTMLParser
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import unquote, urlsplit
from generate import generate, TYPES

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.targets = []
        self.ids = set()
        self.headings = 0
    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        if tag == 'h1':
            self.headings += 1
        for attr in ('src', 'href'):
            if attrs.get(attr):
                self.targets.append(attrs[attr])

class GeneratorTests(unittest.TestCase):
    def test_all_types_both_themes_and_local_links(self):
        with tempfile.TemporaryDirectory() as folder:
            for kind in TYPES:
                for theme in ('escuro', 'claro'):
                    with self.subTest(kind=kind, theme=theme):
                        site = generate(kind, 'Praimos', Path(folder)/f'{kind}-{theme}', theme=theme)
                        manifest = json.loads((site/'site.json').read_text(encoding='utf-8'))
                        self.assertEqual(manifest['type'], kind)
                        self.assertEqual(manifest['theme'], theme)
                        self.assertEqual((site/'robots.txt').read_text(), 'User-agent: *\nDisallow: /\n')
                        for relative in manifest['routes']:
                            page = site/relative
                            parser = Links()
                            html = page.read_text(encoding='utf-8')
                            parser.feed(html)
                            self.assertEqual(parser.headings, 1, str(page))
                            self.assertIn('lang="pt-BR"', html)
                            self.assertIn('noindex,nofollow', html)
                            for target in parser.targets:
                                url = urlsplit(target)
                                self.assertFalse(url.scheme, target)
                                linked = ((page.parent/unquote(url.path)) if url.path else page).resolve()
                                self.assertTrue(linked.is_relative_to(site.resolve()))
                                self.assertTrue(linked.is_file(), str(linked))
                                if url.fragment:
                                    other = Links()
                                    other.feed(linked.read_text(encoding='utf-8'))
                                    self.assertIn(url.fragment, other.ids)
    def test_failed_copy_rolls_back_owned_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)/'failed'
            with patch('generate.shutil.copytree', side_effect=OSError('forced copy failure')):
                with self.assertRaises(OSError):
                    generate('blog', 'Marca', site)
            self.assertFalse(site.exists())
            generate('blog', 'Marca', site)
            self.assertTrue((site/'index.html').is_file())
    def test_unicode_and_raw_json(self):
        with tempfile.TemporaryDirectory() as folder:
            name = 'Café ação 日本 <script> & "teste"'
            site = generate('blog', name, Path(folder)/'unicode')
            data = json.loads((site/'site.json').read_text(encoding='utf-8'))
            self.assertEqual(data['name'], name)
            from html import unescape
            html = (site/'index.html').read_text(encoding='utf-8')
            self.assertIn(name, unescape(html))
    def test_same_input_is_deterministic(self):
        with tempfile.TemporaryDirectory() as folder:
            first = generate('loja', 'Praimos', Path(folder)/'one')
            second = generate('loja', 'Praimos', Path(folder)/'two')
            a = {p.relative_to(first): p.read_bytes() for p in first.rglob('*') if p.is_file()}
            b = {p.relative_to(second): p.read_bytes() for p in second.rglob('*') if p.is_file()}
            self.assertEqual(a, b)
    def test_refuses_empty_existing_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)/'empty'
            site.mkdir()
            with self.assertRaises(FileExistsError):
                generate('blog', 'Marca', site)
            self.assertEqual(list(site.iterdir()), [])
    def test_refuses_existing_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)/'existing'
            site.mkdir()
            sentinel = site/'keep.txt'
            sentinel.write_text('preserve')
            with self.assertRaises(FileExistsError):
                generate('loja', 'Marca', site)
            self.assertEqual(sentinel.read_text(), 'preserve')
            self.assertEqual(len(list(site.iterdir())), 1)
    def test_user_name_is_text_and_path_with_spaces(self):
        with tempfile.TemporaryDirectory() as folder:
            site = generate('blog', '<script>alert("x")</script> & Ação', Path(folder)/'site com espaços')
            html = (site/'index.html').read_text(encoding='utf-8')
            self.assertNotIn('<script>alert(', html)
            self.assertIn('&lt;script&gt;', html)
            self.assertIn('Ação', html)
    def test_invalid_options_create_no_output(self):
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)/'invalid'
            for kwargs in ({'kind':'invalid','name':'Marca'}, {'kind':'blog','name':' '}, {'kind':'loja','name':'Marca','theme':'invalid'}):
                with self.assertRaises(ValueError):
                    generate(destination=site, **kwargs)
                self.assertFalse(site.exists())
    def test_store_preset_and_static_detail(self):
        with tempfile.TemporaryDirectory() as folder:
            site = generate('loja', 'Store', Path(folder)/'loja')
            self.assertIn('data-preset="loja"', (site/'index.html').read_text(encoding='utf-8'))
            detail = (site/'produto/orbita/index.html').read_text(encoding='utf-8')
            self.assertIn('data-price="2990"', detail)
            self.assertIn('Somente nesta página', detail)
            self.assertNotIn('pagamento aprovado', detail.lower())

if __name__ == '__main__':
    unittest.main(verbosity=2)
